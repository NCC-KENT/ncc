import {
  users,
  members,
  schedules,
  type User,
  type UpsertUser,
  type Member,
  type InsertMember,
  type Schedule,
  type InsertSchedule,
  type ScheduleWithMembers,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, gte, and, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Member operations
  createMember(member: InsertMember): Promise<Member>;
  getMembers(): Promise<Member[]>;
  getMembersByType(type: string): Promise<Member[]>;
  getMember(id: string): Promise<Member | undefined>;
  updateMemberStatus(id: string, status: string): Promise<Member>;
  
  // Schedule operations
  createSchedule(schedule: InsertSchedule): Promise<Schedule>;
  getSchedules(): Promise<ScheduleWithMembers[]>;
  getUpcomingSchedules(): Promise<ScheduleWithMembers[]>;
  getSchedule(id: string): Promise<ScheduleWithMembers | undefined>;
  updateSchedule(id: string, updates: Partial<InsertSchedule>): Promise<Schedule>;
  deleteSchedule(id: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Member operations
  async createMember(member: InsertMember): Promise<Member> {
    const [newMember] = await db
      .insert(members)
      .values(member)
      .returning();
    return newMember;
  }

  async getMembers(): Promise<Member[]> {
    return await db.select().from(members).orderBy(desc(members.createdAt));
  }

  async getMembersByType(type: string): Promise<Member[]> {
    return await db
      .select()
      .from(members)
      .where(and(eq(members.ministryType, type), eq(members.status, "approved")))
      .orderBy(members.fullName);
  }

  async getMember(id: string): Promise<Member | undefined> {
    const [member] = await db.select().from(members).where(eq(members.id, id));
    return member;
  }

  async updateMemberStatus(id: string, status: string): Promise<Member> {
    const [member] = await db
      .update(members)
      .set({ status })
      .where(eq(members.id, id))
      .returning();
    return member;
  }

  // Schedule operations
  async createSchedule(schedule: InsertSchedule): Promise<Schedule> {
    const [newSchedule] = await db
      .insert(schedules)
      .values(schedule)
      .returning();
    return newSchedule;
  }

  async getSchedules(): Promise<ScheduleWithMembers[]> {
    const allSchedules = await db
      .select()
      .from(schedules)
      .orderBy(desc(schedules.serviceDate));

    return await this.enrichSchedulesWithMembers(allSchedules);
  }

  async getUpcomingSchedules(): Promise<ScheduleWithMembers[]> {
    const now = new Date();
    const upcomingSchedules = await db
      .select()
      .from(schedules)
      .where(gte(schedules.serviceDate, now))
      .orderBy(schedules.serviceDate);

    return await this.enrichSchedulesWithMembers(upcomingSchedules);
  }

  async getSchedule(id: string): Promise<ScheduleWithMembers | undefined> {
    const [schedule] = await db.select().from(schedules).where(eq(schedules.id, id));
    if (!schedule) return undefined;

    const enriched = await this.enrichSchedulesWithMembers([schedule]);
    return enriched[0];
  }

  async updateSchedule(id: string, updates: Partial<InsertSchedule>): Promise<Schedule> {
    const [schedule] = await db
      .update(schedules)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(schedules.id, id))
      .returning();
    return schedule;
  }

  async deleteSchedule(id: string): Promise<void> {
    await db.delete(schedules).where(eq(schedules.id, id));
  }

  private async enrichSchedulesWithMembers(schedules: Schedule[]): Promise<ScheduleWithMembers[]> {
    const enrichedSchedules: ScheduleWithMembers[] = [];

    for (const schedule of schedules) {
      let serviceLeader: Member | null = null;
      let choirLeader: Member | null = null;
      let choirMemberDetails: Member[] = [];

      // Get service leader
      if (schedule.serviceLeaderId) {
        serviceLeader = await this.getMember(schedule.serviceLeaderId) || null;
      }

      // Get choir leader
      if (schedule.choirLeaderId) {
        choirLeader = await this.getMember(schedule.choirLeaderId) || null;
      }

      // Get choir members
      if (schedule.choirMembers && schedule.choirMembers.length > 0) {
        const choirMembersData = await db
          .select()
          .from(members)
          .where(inArray(members.id, schedule.choirMembers));
        choirMemberDetails = choirMembersData;
      }

      enrichedSchedules.push({
        ...schedule,
        serviceLeader,
        choirLeader,
        choirMemberDetails,
      });
    }

    return enrichedSchedules;
  }
}

export const storage = new DatabaseStorage();
