import { sql } from 'drizzle-orm';
import {
  boolean,
  index,
  jsonb,
  pgTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  isAdmin: boolean("is_admin").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Church members who can be assigned to ministries
export const members = pgTable("members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fullName: text("full_name").notNull(),
  phone: varchar("phone").notNull(),
  email: varchar("email"),
  ageGroup: varchar("age_group"),
  experience: text("experience"),
  availability: text("availability").array(),
  ministryType: varchar("ministry_type").notNull(), // 'choir' or 'leader'
  status: varchar("status").default("pending"), // 'pending', 'approved', 'inactive'
  createdAt: timestamp("created_at").defaultNow(),
});

// Sunday service schedules
export const schedules = pgTable("schedules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  serviceDate: timestamp("service_date").notNull(),
  serviceTime: varchar("service_time").notNull(),
  serviceLeaderId: varchar("service_leader_id").references(() => members.id),
  choirLeaderId: varchar("choir_leader_id").references(() => members.id),
  choirMembers: text("choir_members").array(), // Array of member IDs
  specialNotes: text("special_notes"),
  status: varchar("status").default("scheduled"), // 'scheduled', 'confirmed', 'completed'
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const scheduleRelations = relations(schedules, ({ one }) => ({
  serviceLeader: one(members, {
    fields: [schedules.serviceLeaderId],
    references: [members.id],
  }),
  choirLeader: one(members, {
    fields: [schedules.choirLeaderId],
    references: [members.id],
  }),
}));

export const memberRelations = relations(members, ({ many }) => ({
  serviceSchedules: many(schedules),
  choirSchedules: many(schedules),
}));

// Insert schemas
export const insertMemberSchema = createInsertSchema(members).omit({
  id: true,
  createdAt: true,
});

export const insertScheduleSchema = createInsertSchema(schedules).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertMember = z.infer<typeof insertMemberSchema>;
export type Member = typeof members.$inferSelect;
export type InsertSchedule = z.infer<typeof insertScheduleSchema>;
export type Schedule = typeof schedules.$inferSelect;

// Extended types for API responses
export type ScheduleWithMembers = Schedule & {
  serviceLeader: Member | null;
  choirLeader: Member | null;
  choirMemberDetails: Member[];
};
