import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { insertScheduleSchema, type ScheduleWithMembers, type Member } from "@shared/schema";

const scheduleFormSchema = insertScheduleSchema.extend({
  serviceDate: z.string().min(1, "Service date is required"),
  serviceTime: z.string().min(1, "Service time is required"),
  serviceLeaderId: z.string().optional(),
  choirLeaderId: z.string().optional(),
  choirMembers: z.array(z.string()).default([]),
});

type ScheduleFormData = z.infer<typeof scheduleFormSchema>;

interface ScheduleModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editingSchedule?: ScheduleWithMembers | null;
}

export default function ScheduleModal({ open, onOpenChange, editingSchedule }: ScheduleModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: choirMembers = [] } = useQuery<Member[]>({
    queryKey: ["/api/admin/members/choir"],
    enabled: open,
  });

  const { data: leaders = [] } = useQuery<Member[]>({
    queryKey: ["/api/admin/members/leader"],
    enabled: open,
  });

  const form = useForm<ScheduleFormData>({
    resolver: zodResolver(scheduleFormSchema),
    defaultValues: {
      serviceDate: "",
      serviceTime: "10:00",
      serviceLeaderId: "none",
      choirLeaderId: "none",
      choirMembers: [],
      specialNotes: "",
      status: "scheduled",
    },
  });

  useEffect(() => {
    if (editingSchedule) {
      const date = new Date(editingSchedule.serviceDate);
      const localDate = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
      
      form.reset({
        serviceDate: localDate.toISOString().split('T')[0],
        serviceTime: editingSchedule.serviceTime,
        serviceLeaderId: editingSchedule.serviceLeaderId || "none",
        choirLeaderId: editingSchedule.choirLeaderId || "none",
        choirMembers: editingSchedule.choirMembers || [],
        specialNotes: editingSchedule.specialNotes || "",
        status: editingSchedule.status,
      });
    } else {
      form.reset({
        serviceDate: "",
        serviceTime: "10:00",
        serviceLeaderId: "none",
        choirLeaderId: "none",
        choirMembers: [],
        specialNotes: "",
        status: "scheduled",
      });
    }
  }, [editingSchedule, form]);

  const scheduleMutation = useMutation({
    mutationFn: async (data: ScheduleFormData) => {
      const scheduleData = {
        ...data,
        serviceDate: new Date(data.serviceDate + "T" + data.serviceTime),
        serviceLeaderId: data.serviceLeaderId === "none" ? null : data.serviceLeaderId || null,
        choirLeaderId: data.choirLeaderId === "none" ? null : data.choirLeaderId || null,
      };

      if (editingSchedule) {
        await apiRequest("PUT", `/api/admin/schedules/${editingSchedule.id}`, scheduleData);
      } else {
        await apiRequest("POST", "/api/admin/schedules", scheduleData);
      }
    },
    onSuccess: () => {
      toast({
        title: editingSchedule ? "Schedule Updated" : "Schedule Created",
        description: `The schedule has been successfully ${editingSchedule ? "updated" : "created"}.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/schedules"] });
      queryClient.invalidateQueries({ queryKey: ["/api/schedules/upcoming"] });
      onOpenChange(false);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Operation Failed",
        description: error.message || `Failed to ${editingSchedule ? "update" : "create"} schedule.`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ScheduleFormData) => {
    scheduleMutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="schedule-modal">
        <DialogHeader>
          <DialogTitle>
            {editingSchedule ? "Edit Service Schedule" : "Schedule New Service"}
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="serviceDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Service Date *</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} data-testid="input-service-date" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="serviceTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Service Time *</FormLabel>
                    <FormControl>
                      <Input type="time" {...field} data-testid="input-service-time" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="serviceLeaderId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Service Leader *</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-service-leader">
                        <SelectValue placeholder="Select a service leader" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="none">No leader assigned</SelectItem>
                      {leaders.map((leader) => (
                        <SelectItem key={leader.id} value={leader.id}>
                          {leader.fullName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="choirLeaderId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Choir Team Leader</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-choir-leader">
                        <SelectValue placeholder="Select choir leader" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="none">No choir leader assigned</SelectItem>
                      {choirMembers.map((member) => (
                        <SelectItem key={member.id} value={member.id}>
                          {member.fullName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="choirMembers"
              render={() => (
                <FormItem>
                  <FormLabel>Choir Members</FormLabel>
                  <div className="grid grid-cols-2 gap-3 max-h-40 overflow-y-auto border border-input rounded-lg p-3 bg-background">
                    {choirMembers.map((member) => (
                      <FormField
                        key={member.id}
                        control={form.control}
                        name="choirMembers"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value?.includes(member.id)}
                                onCheckedChange={(checked) => {
                                  const updatedValue = checked
                                    ? [...(field.value || []), member.id]
                                    : (field.value || []).filter((value) => value !== member.id);
                                  field.onChange(updatedValue);
                                }}
                                data-testid={`checkbox-choir-${member.id}`}
                              />
                            </FormControl>
                            <FormLabel className="text-sm font-normal">
                              {member.fullName}
                            </FormLabel>
                          </FormItem>
                        )}
                      />
                    ))}
                  </div>
                  {choirMembers.length === 0 && (
                    <p className="text-sm text-muted-foreground">No choir members available. Approve applications first.</p>
                  )}
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="specialNotes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Special Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Any special instructions or notes for this service..."
                      className="min-h-[80px]"
                      {...field}
                      value={field.value || ""}
                      data-testid="textarea-special-notes"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex gap-4">
              <Button 
                type="submit" 
                disabled={scheduleMutation.isPending}
                data-testid="button-save-schedule"
              >
                {scheduleMutation.isPending 
                  ? (editingSchedule ? "Updating..." : "Creating...") 
                  : (editingSchedule ? "Update Schedule" : "Create Schedule")
                }
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => onOpenChange(false)}
                data-testid="button-cancel-schedule"
              >
                Cancel
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
