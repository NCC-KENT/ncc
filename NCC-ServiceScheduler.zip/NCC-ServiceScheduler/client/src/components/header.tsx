import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Church, Menu } from "lucide-react";
import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Header() {
  const { isAuthenticated, user } = useAuth();
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const navigation = [
    { name: "Home", href: "/" },
    { name: "Schedule", href: "/schedule" },
    { name: "Join Team", href: "/signup" },
  ];

  const adminNavigation = [
    ...navigation,
    { name: "Admin", href: "/admin" },
  ];

  const currentNav = (user as any)?.isAdmin ? adminNavigation : navigation;

  const NavLinks = ({ mobile = false, onClose = () => {} }) => (
    <>
      {currentNav.map((item) => (
        <Link key={item.name} href={item.href}>
          <button
            onClick={onClose}
            className={`${
              mobile ? "block w-full text-left px-4 py-2" : "inline-flex"
            } text-muted-foreground hover:text-foreground transition-colors font-medium ${
              location === item.href ? "text-foreground" : ""
            }`}
            data-testid={`nav-${item.name.toLowerCase().replace(" ", "-")}`}
          >
            {item.name}
          </button>
        </Link>
      ))}
    </>
  );

  return (
    <header className="bg-card border-b border-border shadow-sm">
      <div className="max-w-6xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center space-x-3 cursor-pointer" data-testid="logo">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Church className="text-primary-foreground h-5 w-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Nepali Covenant Church</h1>
                <p className="text-sm text-muted-foreground">Management System</p>
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <NavLinks />
            {isAuthenticated ? (
              <Button asChild variant="outline" data-testid="button-logout">
                <a href="/api/logout">Logout</a>
              </Button>
            ) : (
              <Button asChild data-testid="button-admin-login">
                <a href="/api/login">Admin Login</a>
              </Button>
            )}
          </nav>

          {/* Mobile Navigation */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden" data-testid="button-mobile-menu">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <div className="py-6 space-y-6">
                <div className="space-y-2">
                  <NavLinks mobile onClose={() => setIsOpen(false)} />
                </div>
                {isAuthenticated ? (
                  <Button asChild variant="outline" className="w-full" data-testid="button-logout-mobile">
                    <a href="/api/logout">Logout</a>
                  </Button>
                ) : (
                  <Button asChild className="w-full" data-testid="button-admin-login-mobile">
                    <a href="/api/login">Admin Login</a>
                  </Button>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
