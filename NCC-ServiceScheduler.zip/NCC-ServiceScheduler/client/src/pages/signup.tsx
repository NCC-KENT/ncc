import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Music, Mic, ArrowRight } from "lucide-react";
import Header from "@/components/header";
import { insertMemberSchema } from "@shared/schema";

const signupFormSchema = insertMemberSchema.extend({
  fullName: z.string().min(2, "Full name must be at least 2 characters"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  email: z.string().email().optional().or(z.literal("")),
  ageGroup: z.string().optional(),
  experience: z.string().optional(),
  availability: z.array(z.string()).default([]),
});

type SignupFormData = z.infer<typeof signupFormSchema>;

export default function Signup() {
  const [location] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedType, setSelectedType] = useState<string | null>(null);

  // Check URL params for ministry type
  const urlParams = new URLSearchParams(location.split("?")[1] || "");
  const urlType = urlParams.get("type");

  const form = useForm<SignupFormData>({
    resolver: zodResolver(signupFormSchema),
    defaultValues: {
      fullName: "",
      phone: "",
      email: "",
      ageGroup: "",
      experience: "",
      availability: [],
      ministryType: urlType || "",
      status: "pending",
    },
  });

  const signupMutation = useMutation({
    mutationFn: async (data: SignupFormData) => {
      await apiRequest("POST", "/api/members", data);
    },
    onSuccess: () => {
      toast({
        title: "Application Submitted",
        description: "Thank you for your application! We will review and get back to you soon.",
      });
      form.reset();
      setSelectedType(null);
      queryClient.invalidateQueries({ queryKey: ["/api/admin/members"] });
    },
    onError: (error) => {
      toast({
        title: "Submission Failed",
        description: error.message || "Failed to submit application. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: SignupFormData) => {
    signupMutation.mutate(data);
  };

  const showForm = selectedType || urlType;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-foreground mb-4" data-testid="text-signup-title">
            Join a Ministry Team
          </h1>
          <p className="text-muted-foreground">Become part of our worship and service community</p>
        </div>

        {!showForm ? (
          <div className="grid md:grid-cols-2 gap-8">
            <Card 
              className="cursor-pointer hover:border-secondary transition-colors group"
              onClick={() => setSelectedType("choir")}
              data-testid="card-choir-signup"
            >
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center group-hover:bg-secondary/20 transition-colors mr-4">
                    <Music className="text-secondary h-5 w-5" />
                  </div>
                  <CardTitle className="text-xl">Choir Ministry</CardTitle>
                </div>
                <p className="text-muted-foreground mb-4">
                  Lead worship through music, praise songs, and special performances during church services.
                </p>
                <div className="text-secondary font-medium flex items-center">
                  Sign up for Choir <ArrowRight className="ml-2 h-4 w-4" />
                </div>
              </CardContent>
            </Card>

            <Card 
              className="cursor-pointer hover:border-accent transition-colors group"
              onClick={() => setSelectedType("leader")}
              data-testid="card-leader-signup"
            >
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center group-hover:bg-accent/20 transition-colors mr-4">
                    <Mic className="text-accent h-5 w-5" />
                  </div>
                  <CardTitle className="text-xl">Service Leadership</CardTitle>
                </div>
                <p className="text-muted-foreground mb-4">
                  Guide Sunday worship services through prayer, scripture reading, and spiritual leadership.
                </p>
                <div className="text-accent font-medium flex items-center">
                  Volunteer to Lead <ArrowRight className="ml-2 h-4 w-4" />
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <Card className="max-w-2xl mx-auto" data-testid="signup-form">
            <CardHeader>
              <CardTitle className="text-2xl">
                {(selectedType || urlType) === "choir" ? "Join Choir Ministry" : "Volunteer for Service Leadership"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <input 
                    type="hidden" 
                    {...form.register("ministryType")} 
                    value={selectedType || urlType || ""} 
                  />
                  
                  <div className="grid md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name *</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your full name" {...field} data-testid="input-fullname" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number *</FormLabel>
                          <FormControl>
                            <Input placeholder="+977-98xxxxxxxx" {...field} data-testid="input-phone" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <Input placeholder="your.email@example.com" {...field} data-testid="input-email" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="ageGroup"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Age Group</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-age-group">
                                <SelectValue placeholder="Select age group" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="under-18">Under 18</SelectItem>
                              <SelectItem value="18-25">18-25</SelectItem>
                              <SelectItem value="26-35">26-35</SelectItem>
                              <SelectItem value="36-50">36-50</SelectItem>
                              <SelectItem value="over-50">Over 50</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="experience"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Experience / Skills</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Tell us about your experience or skills relevant to this ministry..."
                            className="min-h-[100px]"
                            {...field}
                            data-testid="textarea-experience"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="availability"
                    render={() => (
                      <FormItem>
                        <FormLabel>Availability</FormLabel>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                          {["Sundays", "Wednesdays", "Special Events", "Holidays"].map((day) => (
                            <FormField
                              key={day}
                              control={form.control}
                              name="availability"
                              render={({ field }) => (
                                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value?.includes(day)}
                                      onCheckedChange={(checked) => {
                                        const updatedValue = checked
                                          ? [...(field.value || []), day]
                                          : (field.value || []).filter((value) => value !== day);
                                        field.onChange(updatedValue);
                                      }}
                                      data-testid={`checkbox-${day.toLowerCase().replace(" ", "-")}`}
                                    />
                                  </FormControl>
                                  <FormLabel className="text-sm font-normal">
                                    {day}
                                  </FormLabel>
                                </FormItem>
                              )}
                            />
                          ))}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex gap-4">
                    <Button 
                      type="submit" 
                      disabled={signupMutation.isPending}
                      data-testid="button-submit-application"
                    >
                      {signupMutation.isPending ? "Submitting..." : "Submit Application"}
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => {
                        setSelectedType(null);
                        form.reset();
                      }}
                      data-testid="button-cancel"
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
