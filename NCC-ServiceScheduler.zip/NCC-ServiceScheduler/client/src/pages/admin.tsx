import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Calendar, Users, Inbox, Plus, Edit, Trash, Music, Mic, Church } from "lucide-react";
import ScheduleModal from "../components/schedule-modal";
import type { ScheduleWithMembers, Member } from "@shared/schema";

export default function Admin() {
  const { isAuthenticated, isLoading, user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<ScheduleWithMembers | null>(null);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: schedules, isLoading: schedulesLoading } = useQuery<ScheduleWithMembers[]>({
    queryKey: ["/api/admin/schedules"],
    retry: false,
  });

  const { data: members, isLoading: membersLoading } = useQuery<Member[]>({
    queryKey: ["/api/admin/members"],
    retry: false,
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/admin/schedules/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Schedule Deleted",
        description: "The schedule has been successfully deleted.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/schedules"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Delete Failed",
        description: error.message || "Failed to delete schedule.",
        variant: "destructive",
      });
    },
  });

  const approveMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("PUT", `/api/admin/members/${id}/status`, { status: "approved" });
    },
    onSuccess: () => {
      toast({
        title: "Member Approved",
        description: "The member has been approved and can now be assigned to schedules.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/members"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Approval Failed",
        description: error.message || "Failed to approve member.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  if (!(user as any)?.isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <Church className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h1 className="text-xl font-bold text-foreground mb-2">Access Denied</h1>
            <p className="text-muted-foreground">You don't have admin permissions to access this page.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleEdit = (schedule: ScheduleWithMembers) => {
    setEditingSchedule(schedule);
    setIsScheduleModalOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this schedule?")) {
      deleteMutation.mutate(id);
    }
  };

  const handleApprove = (id: string) => {
    approveMutation.mutate(id);
  };

  const pendingMembers = members?.filter(m => m.status === "pending") || [];
  const choirMembers = members?.filter(m => m.ministryType === "choir" && m.status === "approved") || [];
  const leaders = members?.filter(m => m.ministryType === "leader" && m.status === "approved") || [];

  return (
    <div className="min-h-screen bg-background">
      {/* Admin Header */}
      <div className="bg-card border-b border-border">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground" data-testid="text-admin-title">
                Admin Dashboard
              </h1>
              <p className="text-muted-foreground">Manage church schedules and ministry teams</p>
            </div>
            <Button asChild variant="outline" data-testid="button-logout-admin">
              <a href="/api/logout">Logout</a>
            </Button>
          </div>
        </div>
      </div>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <Tabs defaultValue="schedule" className="space-y-6">
          <TabsList>
            <TabsTrigger value="schedule" data-testid="tab-schedule">
              <Calendar className="mr-2 h-4 w-4" />
              Schedule Management
            </TabsTrigger>
            <TabsTrigger value="members" data-testid="tab-members">
              <Users className="mr-2 h-4 w-4" />
              Team Members
            </TabsTrigger>
            <TabsTrigger value="applications" data-testid="tab-applications">
              <Inbox className="mr-2 h-4 w-4" />
              Applications
              {pendingMembers.length > 0 && (
                <Badge variant="destructive" className="ml-2">{pendingMembers.length}</Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="schedule" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-foreground">Schedule Management</h2>
              <Button 
                onClick={() => {
                  setEditingSchedule(null);
                  setIsScheduleModalOpen(true);
                }}
                data-testid="button-add-service"
              >
                <Plus className="mr-2 h-4 w-4" />
                Add Service
              </Button>
            </div>

            {schedulesLoading ? (
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center space-x-4">
                        <Skeleton className="h-12 w-12 rounded-full" />
                        <div className="space-y-2 flex-1">
                          <Skeleton className="h-4 w-full" />
                          <Skeleton className="h-4 w-3/4" />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date & Time</TableHead>
                      <TableHead>Service Leader</TableHead>
                      <TableHead>Choir Team</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {schedules && schedules.length > 0 ? (
                      schedules.map((schedule) => (
                        <TableRow key={schedule.id} data-testid={`schedule-row-${schedule.id}`}>
                          <TableCell>
                            <div>
                              <div className="font-medium">
                                {new Date(schedule.serviceDate).toLocaleDateString()}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                {schedule.serviceTime}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            {schedule.serviceLeader ? (
                              <div className="flex items-center">
                                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                                  <Mic className="text-primary h-3 w-3" />
                                </div>
                                <div>
                                  <div className="font-medium">{schedule.serviceLeader.fullName}</div>
                                  <div className="text-sm text-muted-foreground">{schedule.serviceLeader.phone}</div>
                                </div>
                              </div>
                            ) : (
                              <span className="text-muted-foreground">Not assigned</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {schedule.choirLeader || schedule.choirMemberDetails.length > 0 ? (
                              <div className="flex items-center">
                                <div className="w-8 h-8 bg-secondary/10 rounded-full flex items-center justify-center mr-3">
                                  <span className="text-secondary text-sm font-medium">
                                    {schedule.choirMemberDetails.length + (schedule.choirLeader ? 1 : 0)}
                                  </span>
                                </div>
                                <div>
                                  {schedule.choirLeader && (
                                    <div className="font-medium">{schedule.choirLeader.fullName} (Lead)</div>
                                  )}
                                  {schedule.choirMemberDetails.length > 0 && (
                                    <div className="text-sm text-muted-foreground">
                                      +{schedule.choirMemberDetails.length} members
                                    </div>
                                  )}
                                </div>
                              </div>
                            ) : (
                              <span className="text-muted-foreground">Not assigned</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <Badge variant={schedule.status === "confirmed" ? "default" : "secondary"}>
                              {schedule.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleEdit(schedule)}
                                data-testid={`button-edit-${schedule.id}`}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDelete(schedule.id)}
                                className="text-destructive hover:text-destructive"
                                data-testid={`button-delete-${schedule.id}`}
                              >
                                <Trash className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8">
                          <Calendar className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                          <p className="text-muted-foreground">No schedules found. Create your first schedule.</p>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="members" className="space-y-6">
            <h2 className="text-xl font-semibold text-foreground">Team Members</h2>

            {membersLoading ? (
              <div className="grid lg:grid-cols-2 gap-8">
                {[1, 2].map((i) => (
                  <Card key={i}>
                    <CardContent className="p-6">
                      <Skeleton className="h-6 w-32 mb-4" />
                      <div className="space-y-3">
                        {[1, 2, 3].map((j) => (
                          <Skeleton key={j} className="h-16 w-full" />
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid lg:grid-cols-2 gap-8">
                <Card data-testid="card-choir-members">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Music className="text-secondary mr-2 h-5 w-5" />
                      Choir Members
                      <Badge variant="secondary" className="ml-auto">{choirMembers.length} active</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {choirMembers.length > 0 ? (
                      <div className="space-y-3">
                        {choirMembers.map((member) => (
                          <div key={member.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                            <div className="flex items-center">
                              <div className="w-10 h-10 bg-secondary/10 rounded-full flex items-center justify-center mr-3">
                                <span className="text-secondary font-medium text-sm">
                                  {member.fullName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                                </span>
                              </div>
                              <div>
                                <div className="font-medium text-foreground">{member.fullName}</div>
                                <div className="text-sm text-muted-foreground">{member.phone}</div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-muted-foreground text-center py-4">No choir members found.</p>
                    )}
                  </CardContent>
                </Card>

                <Card data-testid="card-service-leaders">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Mic className="text-accent mr-2 h-5 w-5" />
                      Service Leaders
                      <Badge variant="secondary" className="ml-auto">{leaders.length} active</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {leaders.length > 0 ? (
                      <div className="space-y-3">
                        {leaders.map((member) => (
                          <div key={member.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                            <div className="flex items-center">
                              <div className="w-10 h-10 bg-accent/10 rounded-full flex items-center justify-center mr-3">
                                <span className="text-accent font-medium text-sm">
                                  {member.fullName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                                </span>
                              </div>
                              <div>
                                <div className="font-medium text-foreground">{member.fullName}</div>
                                <div className="text-sm text-muted-foreground">{member.phone}</div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-muted-foreground text-center py-4">No service leaders found.</p>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="applications" className="space-y-6">
            <h2 className="text-xl font-semibold text-foreground">Recent Applications</h2>

            {membersLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <Card key={i}>
                    <CardContent className="p-6">
                      <Skeleton className="h-20 w-full" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : pendingMembers.length > 0 ? (
              <div className="space-y-4" data-testid="applications-list">
                {pendingMembers.map((member) => (
                  <Card key={member.id} data-testid={`application-${member.id}`}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center mb-3">
                            <h3 className="font-semibold text-foreground mr-3">{member.fullName}</h3>
                            <Badge variant={member.ministryType === "choir" ? "secondary" : "default"}>
                              {member.ministryType === "choir" ? "Choir Application" : "Leadership Application"}
                            </Badge>
                          </div>
                          <div className="grid md:grid-cols-3 gap-4 text-sm mb-3">
                            <div>
                              <span className="text-muted-foreground">Phone:</span>
                              <span className="text-foreground ml-1">{member.phone}</span>
                            </div>
                            {member.ageGroup && (
                              <div>
                                <span className="text-muted-foreground">Age Group:</span>
                                <span className="text-foreground ml-1">{member.ageGroup}</span>
                              </div>
                            )}
                            <div>
                              <span className="text-muted-foreground">Applied:</span>
                              <span className="text-foreground ml-1">
                                {new Date(member.createdAt!).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                          {member.experience && (
                            <p className="text-muted-foreground text-sm">
                              "{member.experience}"
                            </p>
                          )}
                        </div>
                        <div className="flex space-x-2 ml-4">
                          <Button 
                            className="bg-accent text-accent-foreground hover:bg-accent/90"
                            onClick={() => handleApprove(member.id)}
                            disabled={approveMutation.isPending}
                            data-testid={`button-approve-${member.id}`}
                          >
                            Approve
                          </Button>
                          <Button variant="outline" data-testid={`button-review-${member.id}`}>
                            Review Later
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <Inbox className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">No pending applications</h3>
                  <p className="text-muted-foreground">All applications have been reviewed.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </main>

      <ScheduleModal
        open={isScheduleModalOpen}
        onOpenChange={setIsScheduleModalOpen}
        editingSchedule={editingSchedule}
      />
    </div>
  );
}
