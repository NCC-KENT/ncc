import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Church, Music, Mic, Calendar, UserPlus } from "lucide-react";
import Header from "@/components/header";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary/10 to-secondary/10 py-16">
          <div className="max-w-6xl mx-auto px-4 text-center">
            <div className="mb-8">
              <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-6">
                <Church className="text-primary-foreground h-8 w-8" />
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4" data-testid="text-hero-title">
                Welcome to Nepali Covenant Church
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8" data-testid="text-hero-description">
                Join our community in worship and service. Manage schedules, volunteer for ministry teams, and stay connected with our church family.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild size="lg" data-testid="button-view-schedule">
                  <Link href="/schedule">
                    <Calendar className="mr-2 h-4 w-4" />
                    View Schedule
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg" data-testid="button-join-ministry">
                  <Link href="/signup">
                    <UserPlus className="mr-2 h-4 w-4" />
                    Join a Ministry
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Ministry Teams Section */}
        <section className="py-16 bg-card">
          <div className="max-w-6xl mx-auto px-4">
            <h2 className="text-3xl font-bold text-center text-foreground mb-12" data-testid="text-ministry-title">
              Ministry Teams
            </h2>
            <div className="grid md:grid-cols-2 gap-8">
              <Card className="hover:shadow-lg transition-shadow" data-testid="card-choir-ministry">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Music className="text-secondary h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-4">Choir Team</h3>
                  <p className="text-muted-foreground mb-6">
                    Lead our congregation in worship through music and praise. Join our talented choir team and use your voice to glorify God.
                  </p>
                  <Button asChild className="bg-secondary text-secondary-foreground hover:bg-secondary/90" data-testid="button-join-choir">
                    <Link href="/signup?type=choir">Join Choir</Link>
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow" data-testid="card-leader-ministry">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Mic className="text-accent h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-4">Service Leader</h3>
                  <p className="text-muted-foreground mb-6">
                    Guide our Sunday worship services with prayer, scripture reading, and spiritual leadership for our community.
                  </p>
                  <Button asChild className="bg-accent text-accent-foreground hover:bg-accent/90" data-testid="button-volunteer-lead">
                    <Link href="/signup?type=leader">Volunteer to Lead</Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
