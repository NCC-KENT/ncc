import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Music, Mic, Calendar, Clock } from "lucide-react";
import Header from "@/components/header";
import type { ScheduleWithMembers } from "@shared/schema";

export default function Schedule() {
  const { data: schedules, isLoading, error } = useQuery<ScheduleWithMembers[]>({
    queryKey: ["/api/schedules/upcoming"],
  });

  if (error) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-6xl mx-auto px-4 py-12">
          <div className="text-center">
            <p className="text-muted-foreground">Failed to load schedules. Please try again later.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="max-w-6xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-foreground mb-4" data-testid="text-schedule-title">
            Upcoming Services
          </h1>
          <p className="text-muted-foreground">Stay updated with our worship schedule and ministry assignments</p>
        </div>

        {isLoading ? (
          <div className="space-y-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="overflow-hidden">
                <div className="bg-primary/5 px-6 py-4 border-b border-border">
                  <Skeleton className="h-6 w-48" />
                </div>
                <CardContent className="p-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <Skeleton className="h-20 w-full" />
                    <Skeleton className="h-20 w-full" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : schedules && schedules.length > 0 ? (
          <div className="space-y-6" data-testid="schedule-list">
            {schedules.map((schedule) => (
              <Card key={schedule.id} className="overflow-hidden" data-testid={`schedule-${schedule.id}`}>
                <div className="bg-primary/5 px-6 py-4 border-b border-border">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-foreground flex items-center">
                      <Calendar className="mr-2 h-4 w-4" />
                      {new Date(schedule.serviceDate).toLocaleDateString('en-US', { 
                        weekday: 'long', 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric' 
                      })}
                    </h3>
                    <span className="text-sm text-muted-foreground flex items-center">
                      <Clock className="mr-1 h-3 w-3" />
                      {schedule.serviceTime}
                    </span>
                  </div>
                </div>
                <CardContent className="p-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium text-foreground mb-3 flex items-center">
                        <Mic className="text-primary mr-2 h-4 w-4" />
                        Service Leader
                      </h4>
                      <div className="bg-muted/50 rounded-md p-3">
                        {schedule.serviceLeader ? (
                          <>
                            <p className="font-medium text-foreground" data-testid={`leader-${schedule.id}`}>
                              {schedule.serviceLeader.fullName}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {schedule.serviceLeader.phone}
                            </p>
                          </>
                        ) : (
                          <p className="text-muted-foreground">Not assigned</p>
                        )}
                      </div>
                    </div>
                    <div>
                      <h4 className="font-medium text-foreground mb-3 flex items-center">
                        <Music className="text-secondary mr-2 h-4 w-4" />
                        Choir Team
                      </h4>
                      <div className="bg-muted/50 rounded-md p-3">
                        {schedule.choirLeader || schedule.choirMemberDetails.length > 0 ? (
                          <div className="space-y-1" data-testid={`choir-${schedule.id}`}>
                            {schedule.choirLeader && (
                              <p className="text-sm text-foreground font-medium">
                                • {schedule.choirLeader.fullName} (Lead)
                              </p>
                            )}
                            {schedule.choirMemberDetails.slice(0, 3).map((member) => (
                              <p key={member.id} className="text-sm text-foreground">
                                • {member.fullName}
                              </p>
                            ))}
                            {schedule.choirMemberDetails.length > 3 && (
                              <p className="text-sm text-muted-foreground">
                                +{schedule.choirMemberDetails.length - 3} more members
                              </p>
                            )}
                          </div>
                        ) : (
                          <p className="text-muted-foreground">Not assigned</p>
                        )}
                      </div>
                    </div>
                  </div>
                  {schedule.specialNotes && (
                    <div className="mt-4 pt-4 border-t border-border">
                      <p className="text-sm text-muted-foreground">
                        <strong>Special Notes:</strong> {schedule.specialNotes}
                      </p>
                    </div>
                  )}
                  <div className="mt-4 flex justify-end">
                    <Badge variant={schedule.status === "confirmed" ? "default" : "secondary"}>
                      {schedule.status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Calendar className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">No upcoming services</h3>
            <p className="text-muted-foreground">Check back later for new schedule updates.</p>
          </div>
        )}
      </main>
    </div>
  );
}
